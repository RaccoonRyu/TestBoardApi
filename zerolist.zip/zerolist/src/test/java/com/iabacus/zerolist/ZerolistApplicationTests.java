package com.iabacus.zerolist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZerolistApplicationTests {

	@Test
	void contextLoads() {
	}

}
