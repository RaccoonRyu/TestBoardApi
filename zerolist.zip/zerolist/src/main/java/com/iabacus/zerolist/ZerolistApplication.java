package com.iabacus.zerolist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZerolistApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZerolistApplication.class, args);
	}

}
